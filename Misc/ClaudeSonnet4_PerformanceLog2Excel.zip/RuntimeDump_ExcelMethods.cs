        /// <summary>
        ///  This command creates a file with the name "UsageCPU_YYYYMMDD_hhmmss.txt" in the temporary directory (%USERPROFILE%\AppData\Local\Temp) where the message log is also stored.
        ///   <para>This file outputs statistics about all threads that were created with the "gip.core.datamodel.ACThread" class. Therefore, you should only use the ACThread class for thread programm[...]
        /// </summary>
        [ACMethodInteraction("", "en{'Dump CPU usage'}de{'Dump CPU usage'}",100, true)]
        public void DumpCPU()
        {
            if (!ACThread.PerfLogger.Active)
                return;
            
            DateTime now = DateTime.Now;
            string dumpFilePath = string.Format("{0}UsageCPU_{1:yyyyMMdd_HHmmss}.txt", Messages.LogFilePath, now);
            string excelFilePath = string.Format("{0}UsageCPU.xlsx", Messages.LogFilePath);
            
            // First, get the performance data without resetting
            var perfData = ACThread.PerfLogger.GetPerformanceData();
            
            // Write to Excel (append to existing file)
            if (perfData != null)
                WritePerformanceDataToExcel(excelFilePath, perfData, now);
            
            // Then dump to text file and reset the data
            string log = ACThread.DumpStatisticsAndReset();
            if (log != null)
                File.WriteAllText(dumpFilePath, log);
        }

        /// <summary>
        ///   <para>
        ///  This command creates a file with the name "PerfLog_YYYYMMDD_hhmmss.txt" in the temporary directory (%USERPROFILE%\AppData\Local\Temp) where the message log is also stored.</para>
        ///   <para>This file contains usage statistics for all instances that have status-dependent methods. Status-dependent methods are called cyclically by activation via "PABase .SubscribeToProje[...]
        /// </summary>
        [ACMethodInteraction("", "en{'Dump Performancelog'}de{'Dump Performancelog'}", 101, true)]
        public void DumpPerfLog()
        {
            if (!PerfLogger.Active)
                return;
            
            DateTime now = DateTime.Now;
            string dumpFilePath = string.Format("{0}PerfLog_{1:yyyyMMdd_HHmmss}.txt", Messages.LogFilePath, now);
            string excelFilePath = string.Format("{0}PerfLog.xlsx", Messages.LogFilePath);
            
            // First, get the performance data without resetting
            var perfData = PerfLogger.GetPerformanceData();
            
            // Write to Excel (append to existing file)
            if (perfData != null)
                WritePerformanceDataToExcel(excelFilePath, perfData, now);
            
            // Then dump to text file and reset the data
            string log = PerfLogger.DumpAndReset();
            if (log != null)
                File.WriteAllText(dumpFilePath, log);
        }

        #region Excel Output Methods

        /// <summary>
        /// Writes performance data to Excel file using ClosedXML, appending to existing file if it exists
        /// </summary>
        /// <param name="filePath">Path where Excel file should be saved</param>
        /// <param name="perfData">The performance data from GetPerformanceData()</param>
        /// <param name="dumpTimestamp">Timestamp of this dump</param>
        private void WritePerformanceDataToExcel(string filePath, PerformanceLoggerData perfData, DateTime dumpTimestamp)
        {
            try
            {
                XLWorkbook workbook;
                bool isNewFile = !File.Exists(filePath);

                if (isNewFile)
                {
                    workbook = new XLWorkbook();
                }
                else
                {
                    workbook = new XLWorkbook(filePath);
                }

                using (workbook)
                {
                    // Update or create summary worksheet
                    UpdateSummaryWorksheet(workbook, perfData, dumpTimestamp, isNewFile);

                    // Update or create detail worksheets for each instance
                    foreach (var instanceData in perfData.Instances)
                    {
                        string safeName = GetSafeWorksheetName(instanceData.InstanceName);
                        UpdateInstanceWorksheet(workbook, instanceData, dumpTimestamp, safeName, isNewFile);
                    }

                    workbook.SaveAs(filePath);
                    Messages.LogInfo(this.GetACUrl(), "WritePerformanceDataToExcel", $"Excel file updated: {filePath}");
                }
            }
            catch (Exception ex)
            {
                Messages.LogException(this.GetACUrl(), "WritePerformanceDataToExcel", ex);
            }
        }

        /// <summary>
        /// Updates or creates the summary worksheet
        /// </summary>
        private void UpdateSummaryWorksheet(XLWorkbook workbook, PerformanceLoggerData perfData, DateTime dumpTimestamp, bool isNewFile)
        {
            IXLWorksheet summaryWs;
            
            if (workbook.Worksheets.Contains("Summary"))
            {
                summaryWs = workbook.Worksheet("Summary");
            }
            else
            {
                summaryWs = workbook.Worksheets.Add("Summary");
                CreateSummaryHeaders(summaryWs);
            }

            // Find the next available row
            int nextRow = summaryWs.LastRowUsed()?.RowNumber() + 1 ?? 2;

            // Add summary data for each instance
            foreach (var instanceData in perfData.Instances.OrderByDescending(i => i.TotalExecutionTime))
            {
                double usagePercent = perfData.TotalExecutionTime.TotalMilliseconds > 0 
                    ? (instanceData.TotalExecutionTime.TotalMilliseconds / perfData.TotalExecutionTime.TotalMilliseconds) * 100 
                    : 0;

                summaryWs.Cell(nextRow, 1).Value = instanceData.InstanceName;
                summaryWs.Cell(nextRow, 2).Value = instanceData.TotalExecutionTime.ToString(@"hh\:mm\:ss\.fffffff");
                summaryWs.Cell(nextRow, 3).Value = usagePercent;
                summaryWs.Cell(nextRow, 4).Value = dumpTimestamp;
                nextRow++;
            }

            // Ensure AutoFilter is enabled
            if (summaryWs.RangeUsed() != null)
            {
                summaryWs.RangeUsed().SetAutoFilter();
                summaryWs.Columns().AdjustToContents();
            }
        }

        /// <summary>
        /// Updates or creates an instance detail worksheet
        /// </summary>
        private void UpdateInstanceWorksheet(XLWorkbook workbook, PerformanceLoggerInstanceData instanceData, DateTime dumpTimestamp, string worksheetName, bool isNewFile)
        {
            IXLWorksheet detailWs;
            
            if (workbook.Worksheets.Contains(worksheetName))
            {
                detailWs = workbook.Worksheet(worksheetName);
            }
            else
            {
                detailWs = workbook.Worksheets.Add(worksheetName);
                CreateInstanceHeaders(detailWs);
            }

            // Find the next available row
            int nextRow = detailWs.LastRowUsed()?.RowNumber() + 1 ?? 2;

            // Add detail data for each statistic
            foreach (var statData in instanceData.Statistics.OrderByDescending(s => s.TotalExecutionTime))
            {
                foreach (var eventData in statData.Events.OrderByDescending(e => e.Elapsed))
                {
                    detailWs.Cell(nextRow, 1).Value = statData.Id;
                    detailWs.Cell(nextRow, 2).Value = eventData.StartTime;
                    detailWs.Cell(nextRow, 3).Value = eventData.Elapsed.ToString(@"hh\:mm\:ss\.fffffff");
                    detailWs.Cell(nextRow, 4).Value = eventData.UsagePercent;
                    detailWs.Cell(nextRow, 5).Value = instanceData.InstanceName;
                    detailWs.Cell(nextRow, 6).Value = dumpTimestamp;
                    nextRow++;
                }
            }

            // Ensure AutoFilter is enabled
            if (detailWs.RangeUsed() != null)
            {
                detailWs.RangeUsed().SetAutoFilter();
                detailWs.Columns().AdjustToContents();
            }
        }

        /// <summary>
        /// Creates headers for the summary worksheet
        /// </summary>
        private void CreateSummaryHeaders(IXLWorksheet worksheet)
        {
            worksheet.Cell(1, 1).Value = "Instance";
            worksheet.Cell(1, 2).Value = "Execution Time";
            worksheet.Cell(1, 3).Value = "Usage %";
            worksheet.Cell(1, 4).Value = "Dump Timestamp";

            // Apply header formatting
            var headerRange = worksheet.Range(1, 1, 1, 4);
            headerRange.Style.Font.Bold = true;
            headerRange.Style.Fill.BackgroundColor = XLColor.LightBlue;
            headerRange.Style.Border.OutsideBorder = XLBorderStyleValues.Thick;
        }

        /// <summary>
        /// Creates headers for instance detail worksheets
        /// </summary>
        private void CreateInstanceHeaders(IXLWorksheet worksheet)
        {
            worksheet.Cell(1, 1).Value = "ID";
            worksheet.Cell(1, 2).Value = "Timestamp";
            worksheet.Cell(1, 3).Value = "Execution Time";
            worksheet.Cell(1, 4).Value = "Usage %";
            worksheet.Cell(1, 5).Value = "Instance Name";
            worksheet.Cell(1, 6).Value = "Dump Timestamp";

            // Apply header formatting
            var headerRange = worksheet.Range(1, 1, 1, 6);
            headerRange.Style.Font.Bold = true;
            headerRange.Style.Fill.BackgroundColor = XLColor.LightGreen;
            headerRange.Style.Border.OutsideBorder = XLBorderStyleValues.Thick;
        }

        /// <summary>
        /// Creates a safe worksheet name by removing invalid characters
        /// </summary>
        private string GetSafeWorksheetName(string instanceName)
        {
            if (string.IsNullOrEmpty(instanceName))
                return "Instance";

            // Remove or replace invalid characters for worksheet names
            var invalidChars = new char[] { '\\', '/', '?', '*', '[', ']', ':' };
            string safeName = instanceName;
            
            foreach (char c in invalidChars)
            {
                safeName = safeName.Replace(c, '_');
            }

            // Ensure worksheet name is not too long (Excel limit is 31 characters)
            if (safeName.Length > 31)
            {
                safeName = safeName.Substring(0, 28) + "...";
            }

            return safeName;
        }

        #endregion